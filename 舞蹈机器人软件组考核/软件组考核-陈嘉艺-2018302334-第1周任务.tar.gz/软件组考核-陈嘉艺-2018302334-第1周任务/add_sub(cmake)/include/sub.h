#ifndef SUB
#define SUB

int sub(int a,int b);

#endif
