#ifndef _DATE_H_
#define _DATE_H_

struct Date
{
    int year;
    int month;
    int day;
};

#endif 

