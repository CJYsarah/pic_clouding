#include "../add_sub(make)/sub.h"
int sub(int a,int b)
{
	return a-b;
}
