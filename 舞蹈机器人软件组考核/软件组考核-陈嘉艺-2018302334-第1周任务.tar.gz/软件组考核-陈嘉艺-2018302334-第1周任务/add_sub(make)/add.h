#ifndef ADD
#define ADD

int add(int a,int b);

#endif
