#include <iostream>
using namespace std;

int main()
{
    cout<<"Hello world!"<<endl;
    return 0;
}